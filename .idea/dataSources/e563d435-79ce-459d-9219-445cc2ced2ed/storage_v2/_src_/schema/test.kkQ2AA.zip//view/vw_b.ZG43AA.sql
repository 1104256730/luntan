create definer = v3@`%` view vw_b as
select `test`.`b`.`comment` AS `comment`, `test`.`b`.`b1` AS `b1`, now() AS `now()`, 'abc' AS `abc`
from `test`.`b`;

