create
    definer = v3@`%` procedure no_sql(IN pv_name varchar(10))
begin
    set @sv_name = pv_name;
end;

