create
    definer = v3@`%` procedure hello()
begin select 'abc' from dual;
end;

