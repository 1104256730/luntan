create
    definer = v3@`%` function nameFound(v_id int) returns varchar(30)
begin
    declare v_name varchar(30);
    select name into v_name
    from java 
        where id=v_id;
    return v_name;
end;

