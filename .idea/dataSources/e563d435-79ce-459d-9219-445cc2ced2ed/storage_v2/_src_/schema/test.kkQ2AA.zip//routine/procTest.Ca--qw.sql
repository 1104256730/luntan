create
    definer = v3@`%` procedure procTest(IN num1 int, IN num2 int, OUT result int)
begin
    select num1 +num2 from dual;
    select num1 +num2 into result from dual;
end;

