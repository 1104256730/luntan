create
    definer = v3@`%` function declare_numbers(pv_num1 decimal(15, 2), pv_num2 decimal(15, 2)) returns decimal(15, 2)
begin 
    return pv_num1+pv_num2;
end;

