create
    definer = v3@`%` procedure contains_sql(INOUT pv_whom varchar(20))
begin
    select concat('hello',pv_whom,'!')
        into pv_whom
    from dual;
end;

