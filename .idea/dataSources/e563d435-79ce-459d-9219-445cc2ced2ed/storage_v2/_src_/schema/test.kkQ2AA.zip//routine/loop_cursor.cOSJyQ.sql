create
    definer = v3@`%` procedure loop_cursor()
begin
    declare fetched int default 0;
    declare lv_name varchar(30);
    declare cursor_name cursor for
    select concat(fname,' ' ,lname)from employee;
    declare continue  handler for not found set fetched=1;
    
    open cursor_name;
    cursor_loop:
    loop
        fetch  cursor_name into lv_name;
        if fetched = 1
            then leave cursor_loop;
            end if ;
        select lv_name from dual;
        end loop cursor_loop;
    close cursor_name;
end;

